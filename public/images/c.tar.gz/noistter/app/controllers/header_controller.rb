class HeaderController < ApplicationController
end
