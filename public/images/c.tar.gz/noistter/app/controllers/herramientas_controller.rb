class HerramientasController < ApplicationController
end
