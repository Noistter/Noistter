class FooterController < ApplicationController
end
