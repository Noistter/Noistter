class PrivacidadController < ApplicationController
  def index
  end
end