class LandpageController < ApplicationController
  def index
    @usuarios=8965
    @usuariosconectados=1
    @cuentaeventos=325
    @emitiendoeventos=2
    @rssgenerados=5942
    @busquedas=468979
    @porcentajetl=53
    @porcentajeperfil=16
    @porcentajehashtag=20
    @porcentajetermino=11
    @porcentajepc=48
    @porcentajetablet=21
    @porcentajesmartphone=30
    
   
  end
end
