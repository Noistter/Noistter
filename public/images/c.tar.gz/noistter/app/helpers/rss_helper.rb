module RssHelper
  class Trss
    def initialize (id, username, text, link)
        @id=id
        @username=username
        @text=text
        @link=link
      end
  end
end
