module LandpageHelper
end
