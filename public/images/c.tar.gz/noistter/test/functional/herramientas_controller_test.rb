require 'test_helper'

class HerramientasControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
