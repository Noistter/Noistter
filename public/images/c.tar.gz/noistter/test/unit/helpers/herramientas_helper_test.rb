require 'test_helper'

class HerramientasHelperTest < ActionView::TestCase
end
