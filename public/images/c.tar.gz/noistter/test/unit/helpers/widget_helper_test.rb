require 'test_helper'

class WidgetHelperTest < ActionView::TestCase
end
