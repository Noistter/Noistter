# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Noister::Application.config.secret_token = 'eebbe7315250ce4277dd76d6034d3d6b6998aa5ad8ecb2c391117adf55947368c02f5a60c8337e36cc27e26bb648d18a91e0f66d955eaa09b28ecdfbe036e881'
