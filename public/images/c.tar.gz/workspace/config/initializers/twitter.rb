client = Twitter::REST::Client.new do |config|
  config.consumer_key        = "DogpapbYNWdAf9dOvAgpTQ"
  config.consumer_secret     = "lTXxr4qiGsaO78XeW0ZlA4dKWQka5tuz9crI4Xxm7w4"
  config.access_token        = "2214229796-ZZJIc4KPwyarppXUKR1mUNDEOlxMz0OnirE4oc9"
  config.access_token_secret = "0QR3SzFLHxPVsrstvQqYAmZASpM2kTUAqP4i7d3aU2x86"
end