require 'test_helper'

class LandpageHelperTest < ActionView::TestCase
end
