require 'test_helper'

class EventoHelperTest < ActionView::TestCase
end
