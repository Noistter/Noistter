require 'test_helper'

class PerfilHelperTest < ActionView::TestCase
end
