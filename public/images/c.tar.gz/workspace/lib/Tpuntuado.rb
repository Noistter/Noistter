module Tpuntuado
  class Tpuntuado
    def initialize (id, puntuacion)
      @id=id
      @puntuacion=puntuacion
    end
  end
end