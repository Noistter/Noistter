class LandpageController < ApplicationController
  
    #def index
    #  require 'twitter'
      #client.update("Prueba de require")
      #Twitter:client.follow('titan_92')
      #Twitter:client.update("Estoy siguiendo a un usuario.")
    #end
  
end
