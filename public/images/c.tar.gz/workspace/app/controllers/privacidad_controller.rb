class PrivacidadController < ApplicationController   
end