class ApplicationController < ActionController
end
