require 'twitter-text'
module ApplicationHelper
  include Twitter::Autolink
end
