module HomeHelper
  #include Twitter::Autolink
end
